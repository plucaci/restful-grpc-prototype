package qm.ds.lab2.restservice;

public interface Response {

}
